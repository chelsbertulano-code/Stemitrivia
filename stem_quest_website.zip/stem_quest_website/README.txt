STEM QUEST WEBSITE
==================

FILES
- index.html: website structure and content
- style.css: dark futuristic design and responsive layout
- script.js: quiz questions, timer, scoring, facts, and local leaderboard

HOW TO OPEN
1. Extract the ZIP file.
2. Open the folder.
3. Double-click index.html, or open it with a browser.
4. Internet is needed for the Google Fonts; the website itself works offline without them.

CUSTOMIZE
- Change the project details in the About section of index.html.
- Add or edit trivia questions in the questionBank array in script.js.
- Add more STEM facts in the facts array in script.js.
- The leaderboard uses this browser's local storage. It is not a shared online leaderboard.

NOTE
This is a front-end school-project prototype. A real shared leaderboard, user accounts,
or teacher/admin dashboard would require a backend/database.
