const questionBank = [
 {category:"Science",difficulty:"Easy",q:"What is the chemical symbol for gold?",options:["Ag","Au","Fe","Go"],answer:1,explain:"Au comes from the Latin word aurum, meaning gold."},
 {category:"Science",difficulty:"Easy",q:"Which planet is known as the Red Planet?",options:["Venus","Jupiter","Mars","Mercury"],answer:2,explain:"Iron minerals in Martian soil give the planet its reddish color."},
 {category:"Science",difficulty:"Easy",q:"What gas do plants absorb from the atmosphere during photosynthesis?",options:["Oxygen","Carbon dioxide","Nitrogen","Hydrogen"],answer:1,explain:"Plants use carbon dioxide, water, and light to make sugars."},
 {category:"Science",difficulty:"Medium",q:"What is the SI unit of electric current?",options:["Volt","Ohm","Ampere","Watt"],answer:2,explain:"Electric current is measured in amperes (A)."},
 {category:"Science",difficulty:"Medium",q:"Which part of a cell contains most of its genetic material?",options:["Nucleus","Ribosome","Cell membrane","Cytoplasm"],answer:0,explain:"In eukaryotic cells, most DNA is stored in the nucleus."},
 {category:"Science",difficulty:"Hard",q:"A wave has a frequency of 5 Hz and a wavelength of 2 m. What is its speed?",options:["2.5 m/s","7 m/s","10 m/s","20 m/s"],answer:2,explain:"Wave speed = frequency × wavelength = 5 × 2 = 10 m/s."},
 {category:"Technology",difficulty:"Easy",q:"What does CPU stand for?",options:["Central Processing Unit","Computer Power Utility","Central Program User","Control Processing Unit"],answer:0,explain:"The CPU processes instructions and coordinates computer operations."},
 {category:"Technology",difficulty:"Easy",q:"Which of these is an example of an input device?",options:["Monitor","Speaker","Keyboard","Projector"],answer:2,explain:"A keyboard sends data and commands into a computer."},
 {category:"Technology",difficulty:"Medium",q:"What does AI commonly stand for?",options:["Automated Internet","Artificial Intelligence","Applied Interface","Advanced Input"],answer:1,explain:"Artificial intelligence describes computer systems performing tasks associated with human intelligence."},
 {category:"Technology",difficulty:"Medium",q:"Which number system do computers fundamentally use?",options:["Decimal","Binary","Roman","Octal only"],answer:1,explain:"Digital computers represent information using binary digits: 0 and 1."},
 {category:"Technology",difficulty:"Hard",q:"What is the main purpose of encryption?",options:["Make files larger","Compress images","Protect information by encoding it","Increase screen brightness"],answer:2,explain:"Encryption transforms readable data into coded data that requires a key to read."},
 {category:"Engineering",difficulty:"Easy",q:"Which simple machine is used in a seesaw?",options:["Pulley","Wheel and axle","Lever","Screw"],answer:2,explain:"A seesaw is a first-class lever, with the fulcrum between effort and load."},
 {category:"Engineering",difficulty:"Easy",q:"What material is commonly used as an electrical conductor?",options:["Rubber","Copper","Glass","Wood"],answer:1,explain:"Copper conducts electricity well and is widely used in wiring."},
 {category:"Engineering",difficulty:"Medium",q:"What is the main purpose of a bridge truss?",options:["Decorate the bridge","Distribute loads through connected members","Make the bridge heavier","Stop all vibration"],answer:1,explain:"A truss uses connected structural members to distribute forces efficiently."},
 {category:"Engineering",difficulty:"Medium",q:"Which component stores electrical energy in an electric field?",options:["Resistor","Capacitor","Switch","Fuse"],answer:1,explain:"A capacitor stores energy in the electric field between its conductive plates."},
 {category:"Engineering",difficulty:"Hard",q:"In a series circuit, what happens to the current through each component?",options:["It is the same","It doubles at each component","It becomes zero","It is always different"],answer:0,explain:"A series circuit has one path, so the same current flows through each component."},
 {category:"Mathematics",difficulty:"Easy",q:"What is the square root of 144?",options:["10","11","12","14"],answer:2,explain:"12 × 12 = 144."},
 {category:"Mathematics",difficulty:"Easy",q:"What is 15% of 200?",options:["15","20","30","35"],answer:2,explain:"0.15 × 200 = 30."},
 {category:"Mathematics",difficulty:"Medium",q:"What is the value of x if 3x + 5 = 20?",options:["3","5","7","8"],answer:1,explain:"Subtract 5 to get 3x = 15, then divide by 3: x = 5."},
 {category:"Mathematics",difficulty:"Medium",q:"What is the sum of the interior angles of a triangle?",options:["90°","180°","270°","360°"],answer:1,explain:"The interior angles of every Euclidean triangle add up to 180 degrees."},
 {category:"Mathematics",difficulty:"Hard",q:"A fair six-sided die is rolled. What is the probability of rolling an even number?",options:["1/6","1/3","1/2","2/3"],answer:2,explain:"Three of the six outcomes (2, 4, and 6) are even, so 3/6 = 1/2."}
];
const facts = [
 ["A day on Venus is longer than its year. Venus rotates so slowly that one rotation takes longer than one trip around the Sun.","ASTRONOMY / SCIENCE"],
 ["Your brain contains around 86 billion neurons, which communicate through electrical and chemical signals.","BIOLOGY / SCIENCE"],
 ["The first computer bug was an actual moth found in a computer relay in 1947. The term 'bug' was already used for technical faults.","COMPUTING / TECHNOLOGY"],
 ["The Eiffel Tower can become slightly taller in hot weather because metal expands when heated.","STRUCTURES / ENGINEERING"],
 ["Zero is an even number because it is divisible by 2 with no remainder.","NUMBER THEORY / MATHEMATICS"],
 ["Lightning is hotter than the surface of the Sun for a very brief moment.","PHYSICS / SCIENCE"],
 ["The word 'robot' comes from a Czech word, robota, associated with forced labor.","ROBOTICS / TECHNOLOGY"],
 ["A suspension bridge uses cables to transfer loads to towers and anchorages.","CIVIL ENGINEERING / ENGINEERING"]
];
const $ = id => document.getElementById(id);
let round = [], current = 0, score = 0, timerId = null, seconds = 20, locked = false, lastSettings = {category:"All",difficulty:"Easy"};

$("year").textContent = new Date().getFullYear();
$("menuToggle").addEventListener("click",()=>{const nav=$("mainNav");nav.classList.toggle("open");$("menuToggle").setAttribute("aria-expanded",nav.classList.contains("open"));});
document.querySelectorAll(".nav-link").forEach(a=>a.addEventListener("click",()=>{$("mainNav").classList.remove("open");$("menuToggle").setAttribute("aria-expanded","false");}));
document.querySelectorAll(".category-card").forEach(card=>card.addEventListener("click",()=>{$("categorySelect").value=card.dataset.category;document.querySelector("#quiz").scrollIntoView({behavior:"smooth"});}));

function stopTimer(){if(timerId){clearInterval(timerId);timerId=null;}}
function setPanel(panel){["quizSetup","questionPanel","resultPanel"].forEach(id=>$(id).classList.toggle("hidden",id!==panel));}
function startQuiz(){
 stopTimer();lastSettings={category:$("categorySelect").value,difficulty:$("difficultySelect").value};
 let pool=questionBank.filter(q=>(lastSettings.category==="All"||q.category===lastSettings.category)&&q.difficulty===lastSettings.difficulty);
 if(pool.length<5){pool=questionBank.filter(q=>(lastSettings.category==="All"||q.category===lastSettings.category));}
 pool=pool.sort(()=>Math.random()-.5).slice(0,Math.min(5,pool.length));
 round=pool;current=0;score=0;locked=false;
 if(!round.length){alert("No questions found for this selection.");return;}
 setPanel("questionPanel");showQuestion();
}
function showQuestion(){
 stopTimer();locked=false;seconds=20;
 const q=round[current];
 $("questionCounter").textContent=`QUESTION ${current+1} / ${round.length}`;
 $("questionCategory").textContent=q.category.toUpperCase();
 $("questionText").textContent=q.q;
 $("timer").textContent=seconds;
 $("progressBar").style.width=`${(current/round.length)*100}%`;
 $("feedback").textContent="Select your answer to continue.";
 $("feedback").className="";
 $("nextQuestion").disabled=true;
 $("nextQuestion").textContent=current===round.length-1?"View results →":"Next question →";
 $("answerOptions").innerHTML="";
 q.options.forEach((option,i)=>{
  const b=document.createElement("button");b.className="answer-option";b.textContent=String.fromCharCode(65+i)+".  "+option;
  b.addEventListener("click",()=>chooseAnswer(i));$("answerOptions").appendChild(b);
 });
 timerId=setInterval(()=>{seconds--; $("timer").textContent=seconds;if(seconds<=0){stopTimer();if(!locked)chooseAnswer(-1,true);}},1000);
}
function chooseAnswer(index,timedOut=false){
 if(locked)return;locked=true;stopTimer();
 const q=round[current],buttons=[...$("answerOptions").children];
 buttons.forEach((b,i)=>{b.disabled=true;if(i===q.answer)b.classList.add("correct");else if(i===index)b.classList.add("wrong");});
 if(index===q.answer){score++;$("feedback").textContent="Correct! "+q.explain;$("feedback").className="good";}
 else {$("feedback").textContent=(timedOut?"Time's up. ":"Not quite. ")+q.explain;$("feedback").className="bad";}
 $("nextQuestion").disabled=false;
}
$("startQuiz").addEventListener("click",startQuiz);
$("nextQuestion").addEventListener("click",()=>{current++;if(current<round.length)showQuestion();else showResults();});
function showResults(){
 stopTimer();setPanel("resultPanel");$("questionCounter").textContent="MISSION COMPLETE";$("progressBar").style.width="100%";$("finalScore").textContent=score;
 const pct=score/round.length;
 $("resultTitle").textContent=pct===1?"Outstanding, explorer!":pct>=.6?"Mission accomplished!":"Keep exploring, scientist.";
 $("resultMessage").textContent=`You answered ${score} out of ${round.length} questions correctly. ${pct===1?"A perfect result!": "Every attempt is a chance to learn something new."}`;
 saveScore(score,round.length);
}
$("retryQuiz").addEventListener("click",startQuiz);
$("changeSettings").addEventListener("click",()=>{setPanel("quizSetup");$("questionCounter").textContent="READY WHEN YOU ARE";});
function saveScore(points,total){
 const name=$("playerName").value.trim()||"Explorer";
 let scores=[];try{scores=JSON.parse(localStorage.getItem("stemQuestScores")||"[]");}catch(e){}
 scores.push({name,score:points,total,date:Date.now()});
 scores.sort((a,b)=>(b.score/b.total)-(a.score/a.total)||b.score-a.score);
 scores=scores.slice(0,10);localStorage.setItem("stemQuestScores",JSON.stringify(scores));renderLeaderboard();
}
function renderLeaderboard(){
 let scores=[];try{scores=JSON.parse(localStorage.getItem("stemQuestScores")||"[]");}catch(e){}
 const wrap=$("leaderboardRows");wrap.innerHTML="";
 if(!scores.length){wrap.innerHTML='<div class="empty-state">No scores yet. Complete a quiz to claim your place.</div>';return;}
 scores.forEach((s,i)=>{const row=document.createElement("div");row.className="leader-row";const left=document.createElement("span");left.textContent=`${String(i+1).padStart(2,"0")}  /  ${s.name}`;const right=document.createElement("strong");right.textContent=`${s.score} / ${s.total}`;row.append(left,right);wrap.appendChild(row);});
}
$("nameForm").addEventListener("submit",e=>{e.preventDefault();$("playerName").blur();alert("Your name will be used for your next quiz result.");});
$("newFact").addEventListener("click",()=>{const f=facts[Math.floor(Math.random()*facts.length)];$("factText").textContent=f[0];$("factSource").textContent=f[1];});
renderLeaderboard();
